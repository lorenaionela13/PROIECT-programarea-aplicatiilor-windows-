﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROIECT_C_
{
    [Serializable]
    internal class Rezervari:ICloneable,IComparable<Rezervari>,IcalculPret
    {
        int oraCkeckIn;
        int oraCkeckOut;
        int pretCamera;
        int nrNoptii;
        
        Camere camera;

        public Rezervari(int oraCkeckIn, int oraCkeckOut, int pretCamera,int nrNoptii)
        {
            this.oraCkeckIn = oraCkeckIn;
            this.oraCkeckOut = oraCkeckOut;
            this.pretCamera = pretCamera;
            this.nrNoptii= nrNoptii;
        }

        public int OraCkeckIn { get => oraCkeckIn; set => oraCkeckIn = value; }
        public int OraCkeckOut { get => oraCkeckOut; set => oraCkeckOut = value; }
        public int PretCamera { get => pretCamera; set => pretCamera = value; }
       
        internal Camere Camera { get => camera; set => camera = value; }
        public int NrNoptii { get => nrNoptii; set => nrNoptii = value; }

        public object Clone()
        {
            return new Rezervari(this.oraCkeckIn, this.oraCkeckOut, this.pretCamera,this.nrNoptii);
        }

        public int PretTotal()
        {
           return ( pretCamera*nrNoptii);
        }

        public int PretTotal2(int taxeAditionale)
        {
            int pretFaraTaxe = pretCamera * nrNoptii;
            int pretCuTaxe = pretFaraTaxe + taxeAditionale;
            return pretCuTaxe;
        }

        public  int CompareTo(Rezervari other)
        {
            return this.PretTotal().CompareTo(other.PretTotal());
        }

        public static Rezervari operator ++(Rezervari r)
        {
            r.oraCkeckIn++;
            return r;
        }

        public static Rezervari operator +(Rezervari r1, Rezervari r2)
        {
            return new Rezervari(r1.oraCkeckIn, r1.oraCkeckOut, r1.pretCamera + r2.pretCamera,r1.nrNoptii+r2.nrNoptii);
        }

        public static bool operator <(Rezervari r1, Rezervari r2)
        {
            return r1.PretTotal() < r2.PretTotal();
        }

        public static bool operator >(Rezervari r1, Rezervari r2)
        {
            return r1.PretTotal() > r2.PretTotal();
        }

        

        public void ActualizarePret(int pretNou)
        {
            pretCamera = pretNou;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("\nOra check in= ");
            sb.Append(oraCkeckIn);
            sb.Append("\nOra check out= ");
            sb.Append(oraCkeckOut);
            sb.Append("\n Pret camera:");
            sb.Append(pretCamera);
            sb.Append("\n Numarul de nopti:");
            sb.Append(nrNoptii);
            return sb.ToString();
        }
    }
}
