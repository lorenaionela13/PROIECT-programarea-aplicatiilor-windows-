﻿namespace PROIECT_C_
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.ListViewItem listViewItem9 = new System.Windows.Forms.ListViewItem(new string[] {
            "Ora check-in"}, -1, System.Drawing.SystemColors.Info, System.Drawing.SystemColors.MenuBar, null);
            System.Windows.Forms.ListViewItem listViewItem10 = new System.Windows.Forms.ListViewItem(new string[] {
            "Ora check-out"}, -1, System.Drawing.SystemColors.Info, System.Drawing.Color.Empty, null);
            System.Windows.Forms.ListViewItem listViewItem11 = new System.Windows.Forms.ListViewItem(new string[] {
            "Pret Camera"}, -1, System.Drawing.SystemColors.Info, System.Drawing.Color.Empty, null);
            System.Windows.Forms.ListViewItem listViewItem12 = new System.Windows.Forms.ListViewItem(new string[] {
            "Taxe aditionale"}, -1, System.Drawing.SystemColors.Info, System.Drawing.Color.Empty, null);
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea3 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend3 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.tbNumarPaturi = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tbDenumire = new System.Windows.Forms.TextBox();
            this.tbCamera = new System.Windows.Forms.TextBox();
            this.lvRezeravri = new System.Windows.Forms.ListView();
            this.oraCheckin = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.oreCheckout = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.PretCamera = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lvHotel = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btnAfiseazaInf = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fILEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.salvareInFisierToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fisierTextToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.salvareToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fisierBinarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.restaurareToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hotelToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.informatiiHotelToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.informatiiHotelDinBDToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cameraToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.afisareListaCuCamereToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.afiseazaCameraRezervataToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rezervariToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.afisareRezervareToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.anulareRezervareToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.graficeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.incarcaDateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.afisareGarficToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.graficBarsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.graficPieToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.graficDesenatBarsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.salvareToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.printeazaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.modificareGraficToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.modificareCuloareToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.barsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.textToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.modficareFontToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btnAdaugaCamera = new System.Windows.Forms.Button();
            this.tbOraIn = new System.Windows.Forms.TextBox();
            this.tbPret = new System.Windows.Forms.TextBox();
            this.tbOraOut = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.tbNopti = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.lvCameree = new System.Windows.Forms.ListView();
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader9 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.label2 = new System.Windows.Forms.Label();
            this.btnAnuleaza = new System.Windows.Forms.Button();
            this.lbCamere = new System.Windows.Forms.ListBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.btnModifica = new System.Windows.Forms.Button();
            this.dgvHotel = new System.Windows.Forms.DataGridView();
            this.afiseazaListaCuCamereBDToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.afiseazaRezervareBDToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.afiseazaRezervareBDToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.afiseazaListaCuCamereBDToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHotel)).BeginInit();
            this.SuspendLayout();
            // 
            // tbNumarPaturi
            // 
            this.tbNumarPaturi.Location = new System.Drawing.Point(664, 95);
            this.tbNumarPaturi.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbNumarPaturi.Name = "tbNumarPaturi";
            this.tbNumarPaturi.Size = new System.Drawing.Size(100, 22);
            this.tbNumarPaturi.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Location = new System.Drawing.Point(500, 98);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "Numar paturi";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label3.Location = new System.Drawing.Point(503, 150);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 16);
            this.label3.TabIndex = 3;
            this.label3.Text = "Denumire";
            // 
            // tbDenumire
            // 
            this.tbDenumire.Location = new System.Drawing.Point(664, 142);
            this.tbDenumire.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbDenumire.Name = "tbDenumire";
            this.tbDenumire.Size = new System.Drawing.Size(100, 22);
            this.tbDenumire.TabIndex = 5;
            // 
            // tbCamera
            // 
            this.tbCamera.Location = new System.Drawing.Point(1193, 11);
            this.tbCamera.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbCamera.Multiline = true;
            this.tbCamera.Name = "tbCamera";
            this.tbCamera.Size = new System.Drawing.Size(207, 68);
            this.tbCamera.TabIndex = 7;
            // 
            // lvRezeravri
            // 
            this.lvRezeravri.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.oraCheckin,
            this.oreCheckout,
            this.PretCamera,
            this.columnHeader6});
            this.lvRezeravri.GridLines = true;
            this.lvRezeravri.HideSelection = false;
            this.lvRezeravri.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem9,
            listViewItem10,
            listViewItem11,
            listViewItem12});
            this.lvRezeravri.Location = new System.Drawing.Point(824, 98);
            this.lvRezeravri.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.lvRezeravri.Name = "lvRezeravri";
            this.lvRezeravri.Size = new System.Drawing.Size(576, 95);
            this.lvRezeravri.TabIndex = 8;
            this.lvRezeravri.UseCompatibleStateImageBehavior = false;
            this.lvRezeravri.View = System.Windows.Forms.View.Details;
            // 
            // oraCheckin
            // 
            this.oraCheckin.Text = "Ora check-in";
            this.oraCheckin.Width = 111;
            // 
            // oreCheckout
            // 
            this.oreCheckout.Text = "Ora check-out";
            this.oreCheckout.Width = 100;
            // 
            // PretCamera
            // 
            this.PretCamera.Text = "PretCamera";
            this.PretCamera.Width = 99;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Numarul de nopti";
            this.columnHeader6.Width = 98;
            // 
            // lvHotel
            // 
            this.lvHotel.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5});
            this.lvHotel.GridLines = true;
            this.lvHotel.HideSelection = false;
            this.lvHotel.Location = new System.Drawing.Point(12, 49);
            this.lvHotel.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.lvHotel.Name = "lvHotel";
            this.lvHotel.Size = new System.Drawing.Size(298, 88);
            this.lvHotel.TabIndex = 10;
            this.lvHotel.UseCompatibleStateImageBehavior = false;
            this.lvHotel.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Nume Hotel";
            this.columnHeader1.Width = 88;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Nr locuri parcare";
            this.columnHeader2.Width = 115;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Nr Facilitati";
            this.columnHeader3.Width = 87;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Lista camere ocupate";
            this.columnHeader4.Width = 144;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Lista rezervari";
            this.columnHeader5.Width = 114;
            // 
            // btnAfiseazaInf
            // 
            this.btnAfiseazaInf.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btnAfiseazaInf.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnAfiseazaInf.Location = new System.Drawing.Point(12, 141);
            this.btnAfiseazaInf.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnAfiseazaInf.Name = "btnAfiseazaInf";
            this.btnAfiseazaInf.Size = new System.Drawing.Size(213, 30);
            this.btnAfiseazaInf.TabIndex = 11;
            this.btnAfiseazaInf.Text = "Afiseaza informatii hotel";
            this.btnAfiseazaInf.UseVisualStyleBackColor = false;
            this.btnAfiseazaInf.Click += new System.EventHandler(this.btnAfiseazaInf_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fILEToolStripMenuItem,
            this.hotelToolStripMenuItem,
            this.cameraToolStripMenuItem,
            this.rezervariToolStripMenuItem,
            this.graficeToolStripMenuItem,
            this.modificareGraficToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(1484, 28);
            this.menuStrip1.TabIndex = 12;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fILEToolStripMenuItem
            // 
            this.fILEToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.salvareInFisierToolStripMenuItem});
            this.fILEToolStripMenuItem.Name = "fILEToolStripMenuItem";
            this.fILEToolStripMenuItem.Size = new System.Drawing.Size(49, 24);
            this.fILEToolStripMenuItem.Text = "FILE";
            // 
            // salvareInFisierToolStripMenuItem
            // 
            this.salvareInFisierToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fisierTextToolStripMenuItem,
            this.fisierBinarToolStripMenuItem});
            this.salvareInFisierToolStripMenuItem.Name = "salvareInFisierToolStripMenuItem";
            this.salvareInFisierToolStripMenuItem.Size = new System.Drawing.Size(190, 26);
            this.salvareInFisierToolStripMenuItem.Text = "salvare in fisier";
            // 
            // fisierTextToolStripMenuItem
            // 
            this.fisierTextToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.salvareToolStripMenuItem});
            this.fisierTextToolStripMenuItem.Name = "fisierTextToolStripMenuItem";
            this.fisierTextToolStripMenuItem.Size = new System.Drawing.Size(212, 26);
            this.fisierTextToolStripMenuItem.Text = "salvare fisier text";
            this.fisierTextToolStripMenuItem.Click += new System.EventHandler(this.fisierTextToolStripMenuItem_Click);
            // 
            // salvareToolStripMenuItem
            // 
            this.salvareToolStripMenuItem.Name = "salvareToolStripMenuItem";
            this.salvareToolStripMenuItem.Size = new System.Drawing.Size(158, 26);
            this.salvareToolStripMenuItem.Text = "restaurare";
            this.salvareToolStripMenuItem.Click += new System.EventHandler(this.salvareToolStripMenuItem_Click);
            // 
            // fisierBinarToolStripMenuItem
            // 
            this.fisierBinarToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.restaurareToolStripMenuItem});
            this.fisierBinarToolStripMenuItem.Name = "fisierBinarToolStripMenuItem";
            this.fisierBinarToolStripMenuItem.Size = new System.Drawing.Size(212, 26);
            this.fisierBinarToolStripMenuItem.Text = "salvare fisier binar";
            this.fisierBinarToolStripMenuItem.Click += new System.EventHandler(this.fisierBinarToolStripMenuItem_Click);
            // 
            // restaurareToolStripMenuItem
            // 
            this.restaurareToolStripMenuItem.Name = "restaurareToolStripMenuItem";
            this.restaurareToolStripMenuItem.Size = new System.Drawing.Size(158, 26);
            this.restaurareToolStripMenuItem.Text = "restaurare";
            this.restaurareToolStripMenuItem.Click += new System.EventHandler(this.restaurareToolStripMenuItem_Click);
            // 
            // hotelToolStripMenuItem
            // 
            this.hotelToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.informatiiHotelToolStripMenuItem,
            this.informatiiHotelDinBDToolStripMenuItem});
            this.hotelToolStripMenuItem.Name = "hotelToolStripMenuItem";
            this.hotelToolStripMenuItem.Size = new System.Drawing.Size(60, 24);
            this.hotelToolStripMenuItem.Text = "Hotel";
            // 
            // informatiiHotelToolStripMenuItem
            // 
            this.informatiiHotelToolStripMenuItem.Image = global::PROIECT_C_.Properties.Resources.download__1_;
            this.informatiiHotelToolStripMenuItem.Name = "informatiiHotelToolStripMenuItem";
            this.informatiiHotelToolStripMenuItem.Size = new System.Drawing.Size(244, 26);
            this.informatiiHotelToolStripMenuItem.Text = "Informatii Hotel";
            this.informatiiHotelToolStripMenuItem.Click += new System.EventHandler(this.informatiiHotelToolStripMenuItem_Click);
            // 
            // informatiiHotelDinBDToolStripMenuItem
            // 
            this.informatiiHotelDinBDToolStripMenuItem.Name = "informatiiHotelDinBDToolStripMenuItem";
            this.informatiiHotelDinBDToolStripMenuItem.Size = new System.Drawing.Size(244, 26);
            this.informatiiHotelDinBDToolStripMenuItem.Text = "Informatii hotel din BD";
            this.informatiiHotelDinBDToolStripMenuItem.Click += new System.EventHandler(this.informatiiHotelDinBDToolStripMenuItem_Click);
            // 
            // cameraToolStripMenuItem
            // 
            this.cameraToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.afisareListaCuCamereToolStripMenuItem,
            this.afiseazaCameraRezervataToolStripMenuItem,
            this.afiseazaListaCuCamereBDToolStripMenuItem,
            this.afiseazaListaCuCamereBDToolStripMenuItem1});
            this.cameraToolStripMenuItem.Name = "cameraToolStripMenuItem";
            this.cameraToolStripMenuItem.Size = new System.Drawing.Size(74, 24);
            this.cameraToolStripMenuItem.Text = "Camere";
            // 
            // afisareListaCuCamereToolStripMenuItem
            // 
            this.afisareListaCuCamereToolStripMenuItem.Name = "afisareListaCuCamereToolStripMenuItem";
            this.afisareListaCuCamereToolStripMenuItem.Size = new System.Drawing.Size(264, 26);
            this.afisareListaCuCamereToolStripMenuItem.Text = "afisare lista cu camere";
            this.afisareListaCuCamereToolStripMenuItem.Click += new System.EventHandler(this.afisareListaCuCamereToolStripMenuItem_Click);
            // 
            // afiseazaCameraRezervataToolStripMenuItem
            // 
            this.afiseazaCameraRezervataToolStripMenuItem.Name = "afiseazaCameraRezervataToolStripMenuItem";
            this.afiseazaCameraRezervataToolStripMenuItem.Size = new System.Drawing.Size(264, 26);
            this.afiseazaCameraRezervataToolStripMenuItem.Text = "afiseaza camera rezervata";
            this.afiseazaCameraRezervataToolStripMenuItem.Click += new System.EventHandler(this.afiseazaCameraRezervataToolStripMenuItem_Click);
            // 
            // rezervariToolStripMenuItem
            // 
            this.rezervariToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.afisareRezervareToolStripMenuItem,
            this.anulareRezervareToolStripMenuItem,
            this.afiseazaRezervareBDToolStripMenuItem,
            this.afiseazaRezervareBDToolStripMenuItem1});
            this.rezervariToolStripMenuItem.Name = "rezervariToolStripMenuItem";
            this.rezervariToolStripMenuItem.Size = new System.Drawing.Size(84, 24);
            this.rezervariToolStripMenuItem.Text = "Rezervari";
            // 
            // afisareRezervareToolStripMenuItem
            // 
            this.afisareRezervareToolStripMenuItem.Name = "afisareRezervareToolStripMenuItem";
            this.afisareRezervareToolStripMenuItem.Size = new System.Drawing.Size(208, 26);
            this.afisareRezervareToolStripMenuItem.Text = "Afisare Rezervare";
            this.afisareRezervareToolStripMenuItem.Click += new System.EventHandler(this.afisareRezervareToolStripMenuItem_Click);
            // 
            // anulareRezervareToolStripMenuItem
            // 
            this.anulareRezervareToolStripMenuItem.Name = "anulareRezervareToolStripMenuItem";
            this.anulareRezervareToolStripMenuItem.Size = new System.Drawing.Size(208, 26);
            this.anulareRezervareToolStripMenuItem.Text = "Anulare rezervare";
            this.anulareRezervareToolStripMenuItem.Click += new System.EventHandler(this.anulareRezervareToolStripMenuItem_Click);
            // 
            // graficeToolStripMenuItem
            // 
            this.graficeToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.incarcaDateToolStripMenuItem,
            this.afisareGarficToolStripMenuItem,
            this.salvareToolStripMenuItem1,
            this.printeazaToolStripMenuItem});
            this.graficeToolStripMenuItem.Name = "graficeToolStripMenuItem";
            this.graficeToolStripMenuItem.Size = new System.Drawing.Size(70, 24);
            this.graficeToolStripMenuItem.Text = "Grafice";
            // 
            // incarcaDateToolStripMenuItem
            // 
            this.incarcaDateToolStripMenuItem.Name = "incarcaDateToolStripMenuItem";
            this.incarcaDateToolStripMenuItem.Size = new System.Drawing.Size(180, 26);
            this.incarcaDateToolStripMenuItem.Text = "Incarca date";
            this.incarcaDateToolStripMenuItem.Click += new System.EventHandler(this.incarcaDateToolStripMenuItem_Click);
            // 
            // afisareGarficToolStripMenuItem
            // 
            this.afisareGarficToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.graficBarsToolStripMenuItem,
            this.graficPieToolStripMenuItem,
            this.graficDesenatBarsToolStripMenuItem});
            this.afisareGarficToolStripMenuItem.Name = "afisareGarficToolStripMenuItem";
            this.afisareGarficToolStripMenuItem.Size = new System.Drawing.Size(180, 26);
            this.afisareGarficToolStripMenuItem.Text = "Afisare grafic";
            // 
            // graficBarsToolStripMenuItem
            // 
            this.graficBarsToolStripMenuItem.Name = "graficBarsToolStripMenuItem";
            this.graficBarsToolStripMenuItem.Size = new System.Drawing.Size(219, 26);
            this.graficBarsToolStripMenuItem.Text = "Grafic bars";
            this.graficBarsToolStripMenuItem.Click += new System.EventHandler(this.graficBarsToolStripMenuItem_Click);
            // 
            // graficPieToolStripMenuItem
            // 
            this.graficPieToolStripMenuItem.Name = "graficPieToolStripMenuItem";
            this.graficPieToolStripMenuItem.Size = new System.Drawing.Size(219, 26);
            this.graficPieToolStripMenuItem.Text = "Grafic pie";
            this.graficPieToolStripMenuItem.Click += new System.EventHandler(this.graficPieToolStripMenuItem_Click);
            // 
            // graficDesenatBarsToolStripMenuItem
            // 
            this.graficDesenatBarsToolStripMenuItem.Name = "graficDesenatBarsToolStripMenuItem";
            this.graficDesenatBarsToolStripMenuItem.Size = new System.Drawing.Size(219, 26);
            this.graficDesenatBarsToolStripMenuItem.Text = "Grafic desenat bars";
            this.graficDesenatBarsToolStripMenuItem.Click += new System.EventHandler(this.graficDesenatBarsToolStripMenuItem_Click);
            // 
            // salvareToolStripMenuItem1
            // 
            this.salvareToolStripMenuItem1.Name = "salvareToolStripMenuItem1";
            this.salvareToolStripMenuItem1.Size = new System.Drawing.Size(180, 26);
            this.salvareToolStripMenuItem1.Text = "Salvare";
            this.salvareToolStripMenuItem1.Click += new System.EventHandler(this.salvareToolStripMenuItem1_Click);
            // 
            // printeazaToolStripMenuItem
            // 
            this.printeazaToolStripMenuItem.Name = "printeazaToolStripMenuItem";
            this.printeazaToolStripMenuItem.Size = new System.Drawing.Size(180, 26);
            this.printeazaToolStripMenuItem.Text = "Printeaza";
            this.printeazaToolStripMenuItem.Click += new System.EventHandler(this.printeazaToolStripMenuItem_Click);
            // 
            // modificareGraficToolStripMenuItem
            // 
            this.modificareGraficToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.modificareCuloareToolStripMenuItem,
            this.modficareFontToolStripMenuItem});
            this.modificareGraficToolStripMenuItem.Name = "modificareGraficToolStripMenuItem";
            this.modificareGraficToolStripMenuItem.Size = new System.Drawing.Size(137, 24);
            this.modificareGraficToolStripMenuItem.Text = "Modificare grafic";
            // 
            // modificareCuloareToolStripMenuItem
            // 
            this.modificareCuloareToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.barsToolStripMenuItem,
            this.textToolStripMenuItem});
            this.modificareCuloareToolStripMenuItem.Name = "modificareCuloareToolStripMenuItem";
            this.modificareCuloareToolStripMenuItem.Size = new System.Drawing.Size(217, 26);
            this.modificareCuloareToolStripMenuItem.Text = "Modificare culoare";
            // 
            // barsToolStripMenuItem
            // 
            this.barsToolStripMenuItem.Name = "barsToolStripMenuItem";
            this.barsToolStripMenuItem.Size = new System.Drawing.Size(120, 26);
            this.barsToolStripMenuItem.Text = "Bars";
            this.barsToolStripMenuItem.Click += new System.EventHandler(this.barsToolStripMenuItem_Click);
            // 
            // textToolStripMenuItem
            // 
            this.textToolStripMenuItem.Name = "textToolStripMenuItem";
            this.textToolStripMenuItem.Size = new System.Drawing.Size(120, 26);
            this.textToolStripMenuItem.Text = "text";
            this.textToolStripMenuItem.Click += new System.EventHandler(this.textToolStripMenuItem_Click);
            // 
            // modficareFontToolStripMenuItem
            // 
            this.modficareFontToolStripMenuItem.Name = "modficareFontToolStripMenuItem";
            this.modficareFontToolStripMenuItem.Size = new System.Drawing.Size(217, 26);
            this.modficareFontToolStripMenuItem.Text = "Modficare font";
            this.modficareFontToolStripMenuItem.Click += new System.EventHandler(this.modficareFontToolStripMenuItem_Click);
            // 
            // btnAdaugaCamera
            // 
            this.btnAdaugaCamera.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnAdaugaCamera.Location = new System.Drawing.Point(432, 417);
            this.btnAdaugaCamera.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnAdaugaCamera.Name = "btnAdaugaCamera";
            this.btnAdaugaCamera.Size = new System.Drawing.Size(171, 33);
            this.btnAdaugaCamera.TabIndex = 13;
            this.btnAdaugaCamera.Text = "Rezerva";
            this.btnAdaugaCamera.UseVisualStyleBackColor = true;
            this.btnAdaugaCamera.Click += new System.EventHandler(this.btnAdaugaCamera_Click);
            // 
            // tbOraIn
            // 
            this.tbOraIn.Location = new System.Drawing.Point(664, 214);
            this.tbOraIn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbOraIn.Name = "tbOraIn";
            this.tbOraIn.Size = new System.Drawing.Size(100, 22);
            this.tbOraIn.TabIndex = 14;
            // 
            // tbPret
            // 
            this.tbPret.Location = new System.Drawing.Point(664, 308);
            this.tbPret.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbPret.Name = "tbPret";
            this.tbPret.Size = new System.Drawing.Size(100, 22);
            this.tbPret.TabIndex = 15;
            // 
            // tbOraOut
            // 
            this.tbOraOut.Location = new System.Drawing.Point(664, 255);
            this.tbOraOut.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbOraOut.Name = "tbOraOut";
            this.tbOraOut.Size = new System.Drawing.Size(100, 22);
            this.tbOraOut.TabIndex = 16;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label5.Location = new System.Drawing.Point(503, 316);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(79, 16);
            this.label5.TabIndex = 19;
            this.label5.Text = "PretCamera";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label6.Location = new System.Drawing.Point(503, 263);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(90, 16);
            this.label6.TabIndex = 20;
            this.label6.Text = "Ora check-out";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label7.Location = new System.Drawing.Point(503, 218);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(82, 16);
            this.label7.TabIndex = 21;
            this.label7.Text = "Ora check-in";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label9.Location = new System.Drawing.Point(500, 374);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(79, 16);
            this.label9.TabIndex = 25;
            this.label9.Text = "Numar nopti";
            // 
            // tbNopti
            // 
            this.tbNopti.Location = new System.Drawing.Point(664, 370);
            this.tbNopti.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbNopti.Name = "tbNopti";
            this.tbNopti.Size = new System.Drawing.Size(100, 22);
            this.tbNopti.TabIndex = 26;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.Highlight;
            this.button1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button1.Location = new System.Drawing.Point(12, 256);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(239, 30);
            this.button1.TabIndex = 27;
            this.button1.Text = "Afisare Lista cu Camere";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // lvCameree
            // 
            this.lvCameree.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader8,
            this.columnHeader9});
            this.lvCameree.GridLines = true;
            this.lvCameree.HideSelection = false;
            this.lvCameree.Location = new System.Drawing.Point(12, 178);
            this.lvCameree.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.lvCameree.Name = "lvCameree";
            this.lvCameree.Size = new System.Drawing.Size(239, 72);
            this.lvCameree.TabIndex = 28;
            this.lvCameree.UseCompatibleStateImageBehavior = false;
            this.lvCameree.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Numar Paturi";
            this.columnHeader8.Width = 80;
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "Denumire Camera";
            this.columnHeader9.Width = 102;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label2.Location = new System.Drawing.Point(545, 61);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(176, 16);
            this.label2.TabIndex = 29;
            this.label2.Text = "Introduce-ti informatiile dorite";
            // 
            // btnAnuleaza
            // 
            this.btnAnuleaza.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnAnuleaza.Location = new System.Drawing.Point(634, 417);
            this.btnAnuleaza.Margin = new System.Windows.Forms.Padding(4);
            this.btnAnuleaza.Name = "btnAnuleaza";
            this.btnAnuleaza.Size = new System.Drawing.Size(150, 33);
            this.btnAnuleaza.TabIndex = 30;
            this.btnAnuleaza.Text = "Anuleaza rezervarea";
            this.btnAnuleaza.UseVisualStyleBackColor = true;
            this.btnAnuleaza.Click += new System.EventHandler(this.btnAnuleaza_Click);
            // 
            // lbCamere
            // 
            this.lbCamere.FormattingEnabled = true;
            this.lbCamere.ItemHeight = 16;
            this.lbCamere.Location = new System.Drawing.Point(12, 308);
            this.lbCamere.Margin = new System.Windows.Forms.Padding(4);
            this.lbCamere.Name = "lbCamere";
            this.lbCamere.Size = new System.Drawing.Size(375, 132);
            this.lbCamere.TabIndex = 31;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.chart1);
            this.panel1.Location = new System.Drawing.Point(824, 214);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(594, 270);
            this.panel1.TabIndex = 32;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // chart1
            // 
            chartArea3.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea3);
            legend3.Name = "Legend1";
            this.chart1.Legends.Add(legend3);
            this.chart1.Location = new System.Drawing.Point(17, 15);
            this.chart1.Name = "chart1";
            series3.ChartArea = "ChartArea1";
            series3.Legend = "Legend1";
            series3.Name = "Camere";
            this.chart1.Series.Add(series3);
            this.chart1.Size = new System.Drawing.Size(559, 234);
            this.chart1.TabIndex = 0;
            this.chart1.Text = "chart1";
            // 
            // btnModifica
            // 
            this.btnModifica.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnModifica.Location = new System.Drawing.Point(302, 229);
            this.btnModifica.Name = "btnModifica";
            this.btnModifica.Size = new System.Drawing.Size(126, 48);
            this.btnModifica.TabIndex = 33;
            this.btnModifica.Text = "Modifica";
            this.btnModifica.UseVisualStyleBackColor = true;
            this.btnModifica.Click += new System.EventHandler(this.btnModifica_Click);
            // 
            // dgvHotel
            // 
            this.dgvHotel.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvHotel.Location = new System.Drawing.Point(824, 11);
            this.dgvHotel.Name = "dgvHotel";
            this.dgvHotel.RowHeadersWidth = 51;
            this.dgvHotel.RowTemplate.Height = 24;
            this.dgvHotel.Size = new System.Drawing.Size(326, 68);
            this.dgvHotel.TabIndex = 35;
            // 
            // afiseazaListaCuCamereBDToolStripMenuItem
            // 
            this.afiseazaListaCuCamereBDToolStripMenuItem.Name = "afiseazaListaCuCamereBDToolStripMenuItem";
            this.afiseazaListaCuCamereBDToolStripMenuItem.Size = new System.Drawing.Size(275, 26);
            this.afiseazaListaCuCamereBDToolStripMenuItem.Text = "Insereaza datele in BD";
            //this.afiseazaListaCuCamereBDToolStripMenuItem.Click += new System.EventHandler(this.afiseazaListaCuCamereBDToolStripMenuItem_Click);
            // 
            // afiseazaRezervareBDToolStripMenuItem
            // 
            this.afiseazaRezervareBDToolStripMenuItem.Name = "afiseazaRezervareBDToolStripMenuItem";
            this.afiseazaRezervareBDToolStripMenuItem.Size = new System.Drawing.Size(240, 26);
            this.afiseazaRezervareBDToolStripMenuItem.Text = "Insereaza datele in BD";
            // 
            // afiseazaRezervareBDToolStripMenuItem1
            // 
            this.afiseazaRezervareBDToolStripMenuItem1.Name = "afiseazaRezervareBDToolStripMenuItem1";
            this.afiseazaRezervareBDToolStripMenuItem1.Size = new System.Drawing.Size(240, 26);
            this.afiseazaRezervareBDToolStripMenuItem1.Text = "Afiseaza rezervare BD";
            // 
            // afiseazaListaCuCamereBDToolStripMenuItem1
            // 
            this.afiseazaListaCuCamereBDToolStripMenuItem1.Name = "afiseazaListaCuCamereBDToolStripMenuItem1";
            this.afiseazaListaCuCamereBDToolStripMenuItem1.Size = new System.Drawing.Size(275, 26);
            this.afiseazaListaCuCamereBDToolStripMenuItem1.Text = "Afiseaza lista cu camere BD";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1484, 486);
            this.Controls.Add(this.dgvHotel);
            this.Controls.Add(this.btnModifica);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lbCamere);
            this.Controls.Add(this.btnAnuleaza);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lvCameree);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.tbNopti);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.tbOraOut);
            this.Controls.Add(this.tbPret);
            this.Controls.Add(this.tbOraIn);
            this.Controls.Add(this.btnAdaugaCamera);
            this.Controls.Add(this.btnAfiseazaInf);
            this.Controls.Add(this.lvHotel);
            this.Controls.Add(this.lvRezeravri);
            this.Controls.Add(this.tbCamera);
            this.Controls.Add(this.tbDenumire);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbNumarPaturi);
            this.Controls.Add(this.menuStrip1);
            this.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHotel)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbNumarPaturi;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbDenumire;
        private System.Windows.Forms.TextBox tbCamera;
        private System.Windows.Forms.ListView lvRezeravri;
        private System.Windows.Forms.ColumnHeader oraCheckin;
        private System.Windows.Forms.ColumnHeader oreCheckout;
        private System.Windows.Forms.ColumnHeader PretCamera;
        private System.Windows.Forms.ListView lvHotel;
        private System.Windows.Forms.Button btnAfiseazaInf;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fILEToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem salvareInFisierToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fisierTextToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fisierBinarToolStripMenuItem;
        private System.Windows.Forms.Button btnAdaugaCamera;
        private System.Windows.Forms.TextBox tbOraIn;
        private System.Windows.Forms.TextBox tbPret;
        private System.Windows.Forms.TextBox tbOraOut;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox tbNopti;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ListView lvCameree;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.ColumnHeader columnHeader9;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.ToolStripMenuItem salvareToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem restaurareToolStripMenuItem;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnAnuleaza;
        private System.Windows.Forms.ToolStripMenuItem rezervariToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem afisareRezervareToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem anulareRezervareToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cameraToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem afisareListaCuCamereToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hotelToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem informatiiHotelToolStripMenuItem;
        private System.Windows.Forms.ListBox lbCamere;
        private System.Windows.Forms.ToolStripMenuItem graficeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem incarcaDateToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem afisareGarficToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem salvareToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem printeazaToolStripMenuItem;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.ToolStripMenuItem graficBarsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem graficPieToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem graficDesenatBarsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem modificareGraficToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem modificareCuloareToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem barsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem textToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem modficareFontToolStripMenuItem;
        private System.Windows.Forms.Button btnModifica;
        private System.Windows.Forms.ToolStripMenuItem afiseazaCameraRezervataToolStripMenuItem;
        private System.Windows.Forms.DataGridView dgvHotel;
        private System.Windows.Forms.ToolStripMenuItem informatiiHotelDinBDToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem afiseazaListaCuCamereBDToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem afiseazaListaCuCamereBDToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem afiseazaRezervareBDToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem afiseazaRezervareBDToolStripMenuItem1;
    }
}

