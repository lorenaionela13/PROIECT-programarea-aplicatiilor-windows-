﻿CREATE TABLE [dbo].[Camere]
(
	[Numar paturi] INT NOT NULL PRIMARY KEY, 
    [Denumire camera] NCHAR(10) NULL
)
