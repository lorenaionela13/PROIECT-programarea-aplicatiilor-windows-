﻿CREATE TABLE [dbo].[Rezervari]
(
	[Ora check-in] INT NOT NULL PRIMARY KEY, 
    [Ora check-out] INT NULL, 
    [Pret camera] INT NULL, 
    [Numar nopti] INT NULL
)
