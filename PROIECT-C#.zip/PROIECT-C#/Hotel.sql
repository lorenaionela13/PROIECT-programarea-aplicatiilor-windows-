﻿CREATE TABLE [dbo].[Table]
(
	[Nume Hotel] NCHAR(10) NOT NULL PRIMARY KEY DEFAULT 'Hotel Atlantis', 
    [Numar locuri parcare] INT NULL DEFAULT 30, 
    [Numar Facilitati] INT NULL DEFAULT 9
)
