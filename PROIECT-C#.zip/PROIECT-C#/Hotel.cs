﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROIECT_C_
{
    internal class Hotel: IEnumerable
    {
        string numeHotel;
        int nrLocuriParcare;
        int nrFacilitati;
        List<Camere> listaCamere;
        List<Rezervari> listaRezervari;

        public Hotel(string numeHotel, int nrLocuriParcare, int nrFacilitati, List<Camere> listaCamere, List<Rezervari> listaRezervari)
        {
            this.numeHotel = numeHotel;
            this.nrLocuriParcare = nrLocuriParcare;
            this.nrFacilitati = nrFacilitati;
            this.listaCamere = listaCamere;
            this.listaRezervari = listaRezervari;
        }

        public string NumeFotel { get => numeHotel; set => numeHotel = value; }
        public int NrLocuriParcare { get => nrLocuriParcare; set => nrLocuriParcare = value; }
        public int NrFacilitati { get => nrFacilitati; set => nrFacilitati = value; }
        internal List<Camere> ListaCamere { get => listaCamere; set => listaCamere = value; }
        internal List<Rezervari> ListaRezervari { get => listaRezervari; set => listaRezervari = value; }


        public static Hotel operator +(Hotel hotel, Rezervari rezervare)
        {
            hotel.listaRezervari.Add(rezervare);
            return hotel;
        }

        public static Hotel operator -(Hotel hotel, Rezervari rezervare)
        {
            hotel.listaRezervari.Remove(rezervare);
            return hotel;
        }

        public Camere this[int index]
        {
            get { return listaCamere[index]; }
            set { listaCamere[index] = value; }
        }

        public IEnumerator GetEnumerator()
        {
            foreach (Camere camera in listaCamere)
            {
                yield return camera;
            }

            foreach (Rezervari rezervare in listaRezervari)
            {
                yield return rezervare;
            }
        }

        public void GenerareRaportDetaliat()
        {
            Console.WriteLine($"Raport detaliat pentru hotelul {numeHotel}:");
            Console.WriteLine("-------------------------------------------------");
            Console.WriteLine("Camere rezervate:");
            foreach (var rezervare in listaRezervari)
            {
                Console.WriteLine($"- Ora check-in: {rezervare.OraCkeckIn}, Ora check-out: {rezervare.OraCkeckOut}");
            }
            Console.WriteLine("-------------------------------------------------");
            var camereDisponibile = listaCamere.Count - listaRezervari.Count;
            Console.WriteLine($"Camere disponibile: {camereDisponibile}");
        }

        // Metoda pentru calculul mediei de preț pentru camerele din hotel
        public decimal CalculMediePretCamere()
        {
            if (listaCamere.Count == 0)
            {
                throw new InvalidOperationException("Nu există camere în hotel pentru a calcula media de preț.");
            }
            decimal sumaPreturi = 0;
            foreach (var rezervare in listaRezervari)
            {
                sumaPreturi += rezervare.PretCamera;
            }
            decimal mediePreturi = sumaPreturi / listaCamere.Count;

            return mediePreturi;
        }

    }
}

