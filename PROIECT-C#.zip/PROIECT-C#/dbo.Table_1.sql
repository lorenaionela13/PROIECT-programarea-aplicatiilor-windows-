﻿CREATE TABLE [dbo].[Rezervari]
(
	[Ora check-in] INT NOT NULL PRIMARY KEY, 
    [Ora check-out] INT NULL, 
    [Pret Camera] INT NULL, 
    [Numar Nopti] INT NULL
)
