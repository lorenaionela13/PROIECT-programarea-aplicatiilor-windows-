﻿CREATE TABLE [dbo].[Hotel]
(
	[Nume Hotel] VARCHAR(50) NOT NULL PRIMARY KEY DEFAULT ' Hotel Atlantis', 
    [Numar locuri de parcare] NUMERIC NOT NULL DEFAULT  30, 
    [Numar Facilitati] NUMERIC NOT NULL DEFAULT 9 
)
